bighorn_exitmode="close";
bighorn_resizemode="center";
bighorn_use_scormversion="1.2";
bighorn_use_failed_status=false;
bighorn_ignore_cmi_interactions=false;
bighorn_masterlanguage="en";
bighorn_langlist="en";
