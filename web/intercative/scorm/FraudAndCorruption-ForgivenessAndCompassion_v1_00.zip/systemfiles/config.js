// control if the new content should open in a new popup window
var newWindow = 0;
