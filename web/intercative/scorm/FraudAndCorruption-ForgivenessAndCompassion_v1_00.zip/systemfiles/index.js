aux0=gFld("Fraud and Corruption - Forgiveness and Compassion","")
insDoc(aux0,gLnk("Fraud and Corruption - Forgiveness and Compassion","../player/Player.html?xmlid=../content/000000004699/000000004699&width=1000&height=480",""))
